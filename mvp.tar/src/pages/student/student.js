import Vue from 'vue'
import ElementUI from 'element-ui'
import axios from 'axios'
import student from './student.vue'
import router from '../../router'
import { config } from '@/config/config.js'
import 'element-ui/lib/theme-chalk/index.css'
import 'bootstrap/dist/css/bootstrap.min.css'

Vue.use(ElementUI)
Vue.prototype.$myconfig = config
Vue.prototype.$axios=axios
new Vue({
    el: '#app',
    router,
    components: { 'student': student },
    template: '<student/>'
})


