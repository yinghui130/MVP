<template>
  <div v-if="logInFlag==false">
    <p class="MsoNormal" align="center" style="text-align: center">
      <span style="color: blue">
        <!--  <font size="6" face="黑体">
          <img src="@/assets/ldxh.jpg" width="101" height="79">
          <img src="@/assets/ldzt.jpg" width="220" height="75">
        </font>-->
      </span>
    </p>
    <p class="MsoNormal" align="center" style="text-align: center">
      <span style="color: blue">
        <!-- <font size="6" face="黑体">研究生招生录取通知书邮寄地址查询修改系统</font> -->
      </span>
    </p>
    <br>
    <br>
    <div align="center">
      <el-form ref="logForm" :model="accountInfo" label-width="100px">
        <el-row type="flex" justify="center">
          <el-col :span="10">
            <el-form-item label="考生姓名" prop="username">
              <el-input v-model="accountInfo.username" size="small"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row type="flex" justify="center">
          <el-col :span="10">
            <el-form-item label="身份证号" prop="password">
              <el-input v-model="accountInfo.password" size="small"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row type="flex" justify="center">
          <el-col>
            <el-form-item>
              <el-button type="primary" @click="logIn">登录</el-button>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
    </div>
  </div>
</template>
<script>
import Vue from "vue";
export default Vue.extend({
  name: "logIn",
  data() {
    var str = window.sessionStorage.getItem("studentInfo");
    if(str!=null)
    {
      this.logInFlag=true
    }
    console.log(str);
    return {
      accountInfo: {
        username: "",
        password: ""
      },
      logInFlag: false
    };
  },
  methods: {
    logIn: function() {
      let url = "/api/student/login";

      this.$axios
        .post(
          url +
            "?username=" +
            this.accountInfo.username +
            "&password=" +
            this.accountInfo.password
        )
        .then(response => {
          window.sessionStorage.setItem(
            "studentInfo",
            JSON.stringify(response.data)
          );
          console.log("sessionStorage");
          var str = window.sessionStorage.getItem("studentInfo");
          var obj = JSON.parse(str);
          console.log(obj);
          this.logInFlag = true;
          console.log(response);
          console.log(response.data);
        })
        .catch(error => {
          console.log(error);
        });
      console.log(url);
      console.log(this.accountInfo.username);
      console.log(this.accountInfo.password);
    }
  }
});
</script>
